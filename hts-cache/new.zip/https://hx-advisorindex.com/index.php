</br>

<!doctype html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="google-site-verification" content="RiD0Nb8leTUZnq449KzlY5X-TY_-80GeZWcm8Sazsdc" />
    <title>Find an Advisor, Financial Advisors in Texas | Houston Advisor Registry</title>
    <meta name="description"
        content="Browse profiles to find the top rated Certified Financial Planners in Houston, Texas. Read customer reviews and learn more about your new financial planner. ">
    <meta itemprop="author" content="Houston Advisor Registry">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="apple-touch-icon" sizes="180x180" href="https://hx-advisorindex.com/images/icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="https://hx-advisorindex.com/images/icon.png">
    <link rel="icon" type="image/png" sizes="16x16" href="https://hx-advisorindex.com/images/icon.png">
    <link rel="manifest" href="https://hx-advisorindex.com/images/branding/favicon/site.webmanifest">
    <link rel="mask-icon" href="https://hx-advisorindex.com/images/branding/favicon/safari-pinned-tab.svg"
        color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">
    <meta property="og:title" content="Find an Advisor, Financial Advisors in Houston, Texas ">
    <meta property="og:description"
        content="Browse profiles to find the top rated Certified Financial Planners in Houston, Texas. Read customer reviews and learn more about your new financial planner. ">
    <meta property="og:image" content="../../images/branding/advisor_registry_default_og.png">
    <meta property="og:url" content="houston-texas.html">
    <meta name="twitter:card" content="summary_large_image">
    <meta property="og:site_name" content="Houston Advisor Registry">
    <meta name="twitter:image:alt" content="Houston Advisor Registry">
    <meta name="csrf-token" content="y9wsEJknAdWZYtKy8A8cHHfzcc1W2Q6u2lW1h6M8">
    <link rel="canonical" href="houston-texas.html" />
    <link rel="stylesheet" href="../../css/app8d90.css?id=fb5c9f7cea599925fdab">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    <!--<script async defer src="../../../kit.fontawesome.com/0109c2cbe4.js" crossorigin="anonymous"></script>-->

    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link
        href="https://fonts.googleapis.com/css2?family=Lato:wght@400;700&amp;family=Nunito+Sans:wght@700;800&amp;display=swap"
        rel="stylesheet">

    <meta name="robots" content="index">

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-63269845-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag() { dataLayer.push(arguments); }
        gtag('js', new Date());

        gtag('config', 'UA-63269845-1');
    </script>


    <script data-ad-client="ca-pub-6110500651740892" google_adtest="on" async
        src="../../../pagead2.googlesyndication.com/pagead/js/f.txt"></script>

</head>

<body class="d-flex flex-column" data-spy="scroll" data-target=".on-page" data-offset="50">
    <a id="top"></a>
    <div id="app" class="page-content ">
        <!-- message output -->
        <!--[if lt IE 8]>
                <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
            <![endif]-->
        <div class="logo-header pt-4 pb-4">
            <div class="container">
                <div class="row">
                    <div class="col-md-5 text-right order-md-2">
                        <div class="actions">
                           <!-- <ul>
                                <li><a href="https://hx-advisorindex.com/login">Sign In</a></li>
                                <li><a href="https://hx-advisorindex.com/register">Create an Account</a></li>
                                <li class="lst"><a href="https://hx-advisorindex.com/update-your-profile">Update Your
                                        Profile</a></li>
                            </ul>
                            -->

                        </div>
                    </div>
                    <div class="col-md-7 order-md-1">
                        <button class="navbar-toggler d-lg-none mr-3" type="button" data-toggle="collapse"
                            data-target="#collapsibleNavId" aria-controls="collapsibleNavId" aria-expanded="false"
                            aria-label="Toggle navigation">
                            <i class="fa fa-bars" aria-hidden="true"></i>
                        </button>
                        <a href="https://hx-advisorindex.com/"><img src="https://hx-advisorindex.com/images/FSP_AR_logo.gif"
                                alt="FSP Houston Advisor Registry - Find an Advisor" class="site-logo" /></a>

                    </div>

                </div>
            </div>
        </div>
        <nav class="navbar navbar-main navbar-expand-lg navbar-dark bg-primary">
            <div class="container">
                <div class="row">
                    <div class="collapse navbar-collapse" id="collapsibleNavId">
                        <ul class="navbar-nav ml-auto mt-lg-0">
                            <li class="nav-item">
                                <a class="nav-link main" href="https://national.societyoffsp.org/page/page1"
                                    target="_blank">About FSP</a>
                            </li>


                            <li class="nav-item">
                                <a class="nav-link main"
                                    href="https://hx-advisorindex.com/advisor-certificates.html">Advisor Certificates</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link main" href="https://hx-advisorindex.com/partners.html">Our Partners</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link main" href="https://hx-advisorindex.com/contact.html">Contact us</a>
                            </li>

                        </ul>
                    </div>
                </div>
            </div>
        </nav>
        <!--
<section class="alert alert-warning mb-0">
    <div class="container pt-4 pb-4">
        <div class="row">
            <div class="col-md-8">
                <div class="">
                    <p class="h2 m-0">
                        <a href="https://calendly.com/rssa/consultation"><i class="fas fa-info-circle"></i> Maximize Your Social Security Benefits</a>
                    </p>
                    <p class="text-dark">Schedule a Free Consultation with an RSSA Social Security Expert</p>
                    
                </div>
            </div>
            <div class="col-md-4 text-md-right">
                <a href="https://calendly.com/rssa/consultation" class="btn btn-success btn-xl">Schedule My Appointment</a>
            </div>
        </div>
    </div>
</section>
-->
        <div class="jumbotron">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="display-3"><span class="text-capitalize">Houston Financial Planners</h1>
                        <p class="lead">Find a Financial Planner in Houston, Texas</p>
                        <a href="https://hx-advisorindex.com/"
                            class="btn btn-outline btn-lg --long">View All Texas Advisors</a>
                        <br />
                    </div>
                </div>
            </div>

        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="filter-bar">
                        <nav>
                            <ul class="pagination">

                                <li class="page-item disabled" aria-disabled="true">
                                    <span class="page-link">Prev</span>
                                </li>


                                <li class="page-item">
                                    <a class="page-link" href="houston-texas.html?page=2" rel="next">Next</a>
                                </li>
                            </ul>
                        </nav>
                        <span class="item d-none d-md-block"><strong>6 Advisors Found</strong></span>
                        <div class="filter-form">
                            <form action="#" class="form-inline" method="GET">
                                <select class="form-control selectpicker selectsubmit" name="order_by" id="order_by">
                                    <option default="default" selected="selected" disabled value="">Order Results By
                                    </option>
                                    <option value="last_name">Last Name </option>
                                    <option value="repscore">Reputation </option>
                                    <option value="review_count">Number of Reviews </option>
                                    <option value="rating">Customer Rating </option>

                                </select>
                                <select class="form-control selectpicker selectsubmit" name="sort" id="sort">
                                    <option default="default" value="desc">Descending</option>
                                    <option value="asc">Ascending</option>
                                </select>
                                <input type="hidden" name="start" id="start" value="">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-md-8 listing-display">
                    <!--PHP LOOP-->
                    
                                        
                       <div class="listing-block">
                        <div class="row">
                            <div class="col-lg-2 col-md-3 col-4 listing-image">
                                <img class="img-fluid profile-img"
                                    src="https://advisor-registry.org/images/branding/profile.svg" alt="personimage">

                            </div>
                            <div class="col-lg-7 col-md-6 col-8 listing-content">
                                <h4>Joni Abalos</h4>
                                
                                Merrill Lynch, Pierce, Fenner & Smith Incorporated                                
                                <p class="address mb-0">Houston, Texas</p>
                                <star-rating v-bind:rating="0.0" v-bind:star-size="25" v-bind:increment="0.1"
                                    v-bind:show-rating="false" v-bind:inline="true"
                                    v-bind:read-only="true"></star-rating>
                                <span class="inline-stars">0 Reviews</span>

                            </div>
                            <div class="col-md-3 listing-buttons">
                                <a class="btn btn-primary" href="financial-advisors/profile.php?advisor=2">View <span
                                        class="d-inline-block d-md-none d-lg-inline-block">Profile</span></a>
                            </div>
                        </div>
                    </div>



                                        
                       <div class="listing-block">
                        <div class="row">
                            <div class="col-lg-2 col-md-3 col-4 listing-image">
                                <img class="img-fluid profile-img"
                                    src="https://advisor-registry.org/images/branding/profile.svg" alt="personimage">

                            </div>
                            <div class="col-lg-7 col-md-6 col-8 listing-content">
                                <h4>Nathalie Abaunza</h4>
                                
                                Bbva Securities Inc.                                
                                <p class="address mb-0">Houston, Texas</p>
                                <star-rating v-bind:rating="0.0" v-bind:star-size="25" v-bind:increment="0.1"
                                    v-bind:show-rating="false" v-bind:inline="true"
                                    v-bind:read-only="true"></star-rating>
                                <span class="inline-stars">0 Reviews</span>

                            </div>
                            <div class="col-md-3 listing-buttons">
                                <a class="btn btn-primary" href="financial-advisors/profile.php?advisor=3">View <span
                                        class="d-inline-block d-md-none d-lg-inline-block">Profile</span></a>
                            </div>
                        </div>
                    </div>



                                        
                       <div class="listing-block">
                        <div class="row">
                            <div class="col-lg-2 col-md-3 col-4 listing-image">
                                <img class="img-fluid profile-img"
                                    src="https://advisor-registry.org/images/branding/profile.svg" alt="personimage">

                            </div>
                            <div class="col-lg-7 col-md-6 col-8 listing-content">
                                <h4>Essmildaa Morgan</h4>
                                
                                PFS Investments LLC                                
                                <p class="address mb-0">Houston, Texas</p>
                                <star-rating v-bind:rating="0.0" v-bind:star-size="25" v-bind:increment="0.1"
                                    v-bind:show-rating="false" v-bind:inline="true"
                                    v-bind:read-only="true"></star-rating>
                                <span class="inline-stars">0 Reviews</span>

                            </div>
                            <div class="col-md-3 listing-buttons">
                                <a class="btn btn-primary" href="financial-advisors/profile.php?advisor=4">View <span
                                        class="d-inline-block d-md-none d-lg-inline-block">Profile</span></a>
                            </div>
                        </div>
                    </div>



                                        
                       <div class="listing-block">
                        <div class="row">
                            <div class="col-lg-2 col-md-3 col-4 listing-image">
                                <img class="img-fluid profile-img"
                                    src="https://advisor-registry.org/images/branding/profile.svg" alt="personimage">

                            </div>
                            <div class="col-lg-7 col-md-6 col-8 listing-content">
                                <h4>Caitlin Abbott</h4>
                                
                                Lpl Financial Llc                                
                                <p class="address mb-0">Houston, Texas</p>
                                <star-rating v-bind:rating="0.0" v-bind:star-size="25" v-bind:increment="0.1"
                                    v-bind:show-rating="false" v-bind:inline="true"
                                    v-bind:read-only="true"></star-rating>
                                <span class="inline-stars">0 Reviews</span>

                            </div>
                            <div class="col-md-3 listing-buttons">
                                <a class="btn btn-primary" href="financial-advisors/profile.php?advisor=5">View <span
                                        class="d-inline-block d-md-none d-lg-inline-block">Profile</span></a>
                            </div>
                        </div>
                    </div>



                                        
                       <div class="listing-block">
                        <div class="row">
                            <div class="col-lg-2 col-md-3 col-4 listing-image">
                                <img class="img-fluid profile-img"
                                    src="https://advisor-registry.org/images/branding/profile.svg" alt="personimage">

                            </div>
                            <div class="col-lg-7 col-md-6 col-8 listing-content">
                                <h4>Michael Abdouch</h4>
                                
                                Coastal Securities, Inc.                                
                                <p class="address mb-0">Houston, Texas</p>
                                <star-rating v-bind:rating="0.0" v-bind:star-size="25" v-bind:increment="0.1"
                                    v-bind:show-rating="false" v-bind:inline="true"
                                    v-bind:read-only="true"></star-rating>
                                <span class="inline-stars">0 Reviews</span>

                            </div>
                            <div class="col-md-3 listing-buttons">
                                <a class="btn btn-primary" href="financial-advisors/profile.php?advisor=9">View <span
                                        class="d-inline-block d-md-none d-lg-inline-block">Profile</span></a>
                            </div>
                        </div>
                    </div>



                                        
                       <div class="listing-block">
                        <div class="row">
                            <div class="col-lg-2 col-md-3 col-4 listing-image">
                                <img class="img-fluid profile-img"
                                    src="https://advisor-registry.org/images/branding/profile.svg" alt="personimage">

                            </div>
                            <div class="col-lg-7 col-md-6 col-8 listing-content">
                                <h4>Robert Abercrombie</h4>
                                
                                Prudential Financial Planning Services                                
                                <p class="address mb-0">Houston, Texas</p>
                                <star-rating v-bind:rating="0.0" v-bind:star-size="25" v-bind:increment="0.1"
                                    v-bind:show-rating="false" v-bind:inline="true"
                                    v-bind:read-only="true"></star-rating>
                                <span class="inline-stars">0 Reviews</span>

                            </div>
                            <div class="col-md-3 listing-buttons">
                                <a class="btn btn-primary" href="financial-advisors/profile.php?advisor=13">View <span
                                        class="d-inline-block d-md-none d-lg-inline-block">Profile</span></a>
                            </div>
                        </div>
                    </div>



                                        
                       <div class="listing-block">
                        <div class="row">
                            <div class="col-lg-2 col-md-3 col-4 listing-image">
                                <img class="img-fluid profile-img"
                                    src="https://advisor-registry.org/images/branding/profile.svg" alt="personimage">

                            </div>
                            <div class="col-lg-7 col-md-6 col-8 listing-content">
                                <h4>Courtney Acarregui</h4>
                                
                                Axa Advisors, Llc                                
                                <p class="address mb-0">Houston, Texas</p>
                                <star-rating v-bind:rating="0.0" v-bind:star-size="25" v-bind:increment="0.1"
                                    v-bind:show-rating="false" v-bind:inline="true"
                                    v-bind:read-only="true"></star-rating>
                                <span class="inline-stars">0 Reviews</span>

                            </div>
                            <div class="col-md-3 listing-buttons">
                                <a class="btn btn-primary" href="financial-advisors/profile.php?advisor=21">View <span
                                        class="d-inline-block d-md-none d-lg-inline-block">Profile</span></a>
                            </div>
                        </div>
                    </div>



                    

                    <!--LOOP END-->
                </div>
                <div class="col-md-4">
                    <aside>
                        <div class="sidebar-block">
                            <div class="content">
                                <h5 class="title">Need Help Planning Your Finances?</h5>
                                <p>We can match you up with a financial advisor in in Houston, Texas with
                                    experience handling your specific financial needs for free. Simply provide your
                                    contact details, and we'll do the rest.</p>
                                <a href="https://hx-advisorindex.com/contact.html"
                                    class="btn btn-outline btn-lg main --long">Find an Advisor</a>
                            </div>
                        </div>
                    </aside>
                    <aside>
                        <div class="sidebar-block">
                            <div class="content pt-0">
                                <h4 class=" pt-4 h5">Recent Articles</h4>
                                <ul class="s-list">
                                    <li class="row pt-3">
                                        <div class="col-md-12">
                                            <h6 class="mb-0">
                                                <a
                                                    href="https://hx-advisorindex.com/articles/social-security-cost-of-living-adjustments.html">Social
                                                    Security: Cost-of-Living Adjustments</a>
                                            </h6>
                                            <small class="text-muted">January 25, 2024</small>
                                            <p class="mt-2"></p>
                                        </div>
                                    </li>
                                    <li class="row pt-3">
                                        <div class="col-md-12">
                                            <h6 class="mb-0">
                                                <a
                                                    href="https://hx-advisorindex.com/articles/the-retirement-savings-contribution-credit-and-the-savers-match.html">The
                                                    Retirement Savings Contribution Credit and the Saver’s Match</a>
                                            </h6>
                                            <small class="text-muted">January 25, 2024</small>
                                            <p class="mt-2"></p>
                                        </div>
                                    </li>
                                    <li class="row pt-3">
                                        <div class="col-md-12">
                                            <h6 class="mb-0">
                                                <a
                                                    href="https://hx-advisorindex.com/articles/529-plans-learn-the-tax-and-financial-planning-benefits-of-college-savings.html">529
                                                    Plans: Learn the Tax and Financial Planning Benefits of College
                                                    Savings</a>
                                            </h6>
                                            <small class="text-muted">January 25, 2024</small>
                                            <p class="mt-2"></p>
                                        </div>
                                    </li>
                                </ul>

                                <!--<a href="https://hx-advisorindex.com/articles" class="btn-lg btn btn-outline">View Our-->
                                <!--    Archive</a>-->
                            </div>
                        </div>
                    </aside>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="filter-bar">
                        <nav>
                            <ul class="pagination">

                                <li class="page-item disabled" aria-disabled="true">
                                    <span class="page-link">Prev</span>
                                </li>


                                <li class="page-item">
                                    <a class="page-link" href="houston-texas.html?page=2" rel="next">Next</a>
                                </li>
                            </ul>
                        </nav>
                        <span class="item d-none d-md-block">Advisors Found: <strong>6</strong></span><span
                            class="item">Page 1</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <ol class="breadcrumb">

                    <li class="breadcrumb-item"><a href="https://hx-advisorindex.com/">Home</a></li>


                    <li class="breadcrumb-item">Advisors
                    </li>

                    <li class="breadcrumb-item active">Houston</li>

                </ol>


                <script
                    type="application/ld+json">{"@context":"http:\/\/schema.org","@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"item":{"@id":"https:\/\/advisor-registry.org","name":"Home","image":null}},{"@type":"ListItem","position":2,"item":{"@id":"https:\/\/advisor-registry.org\/financial-advisors","name":"Advisors","image":null}},{"@type":"ListItem","position":3,"item":{"@id":"https:\/\/advisor-registry.org\/financial-advisors\/Texas","name":"Texas","image":null}},{"@type":"ListItem","position":4,"item":{"@id":"https:\/\/advisor-registry.org\/financial-advisors\/5\/296328","name":"Houston","image":null}}]}</script>

            </div>
        </div>
    </div>
    <footer id="footer">
        <div class="container">

            <div class="row links">
                <div class="col-md-7">
                    <div class="link-list">
                        <h6>Company</h6>
                        <ul>
                            <li><a href="https://national.societyoffsp.org/page/page1">About Us</a></li>
                            <li><a href="https://hx-advisorindex.com/contact.html">Contact Us</a></li>
                            <li><a href="https://hx-advisorindex.com/partners.html">Our Partners</a></li>
                            <li><a href="https://hx-advisorindex.com/privacy.html">Privacy Policy</a></li>
                            <li><a href="https://hx-advisorindex.com/terms-of-use.html">Terms of Use</a></li>
                        </ul>
                    </div>

                    <div class="link-list">
                        <h6>Financial Advisors</h6>
                        <ul>
                            <li><a href="https://hx-advisorindex.com/advisor-certificates.html">Advisor Certificates</a>
                            </li>
                            <li><a href="https://www.diplomaframe.com/usrs">Certificate Frames</a></li>
                        </ul>
                    </div>



                </div>

                <div class="nl">
                    <!--START OF SUBSCRIPTION FORM, CUT FROM HERE DOWN-->
                    <script type="text/javascript"
                        src="https://ui.reachmail.net/api/lists/SubscriptionForm/optin/dynamic/8a2aac18-c0eb-43f8-8a53-ad6300bec367"></script>

                    <div id="rmSubsrciptionForm" class="rmSubsrciptionFormBody">
                        <div class="form-container">
                            <form name="rm_signup_form" action="https://hx-advisorindex.com/contact.html"
                                class="form-container">
                                <h6>Join Our Mailing List</h6>
                                <input class="form-field" type="email" id="email" required=""
                                    placeholder="Email address" aria-label="Email address" autocomplete="email"><br>
                                <button name="submit" type="submit" id="contact-submit" class="btn btn-primary"
                                    data-submit="...Sending">Join</button>

                            </form>
                        </div>
                    </div>

                    <!--FORM ENDS HERE-->

                </div>

                <div class="col-md-12 pb-3">
                </div>
            </div>

        </div>
        <div class="copyright">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        &copy;Advisor Registry
                        <script>document.write(new Date().getFullYear())</script> | All Rights Reserved.
                        The National Directory of U.S. Registered Securities Representatives and Advisors, has no
                        affiliation with any U.S. government agency.
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- <script src="https://cdn.jsdelivr.net/npm/vue@2.6.0"></script> -->
    <script async defer
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDYEzbxJwSqv40iSsVLgp4tOr4IBfWEopM"></script>
    <script src="../../js/app4752.js?id=0ad860b59c63ca68966c"></script>

    <div class="loading">
        <div class="loadingio-spinner-pulse-1uq6qwnuri6h">
            <div class="ldio-dk9p05cys0t">
                <div></div>
                <div></div>
                <div></div>
            </div>
        </div>
    </div>
    <!-- accessibility -->
    <script
        type="text/javascript">!function () { var b = function () { window.__AudioEyeSiteHash = "02f4d8469ef0dcf150f150a682953a5e"; var a = document.createElement("script"); a.src = "../../../wsmcdn.audioeye.com/aem.js"; a.type = "text/javascript"; a.setAttribute("async", ""); document.getElementsByTagName("body")[0].appendChild(a) }; "complete" !== document.readyState ? window.addEventListener ? window.addEventListener("load", b) : window.attachEvent && window.attachEvent("onload", b) : b() }();</script>
</body>
</html>